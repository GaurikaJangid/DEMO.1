﻿


using CusEx;

try
{
    BankAccount account = new BankAccount("1234567890", 1000);
    Console.WriteLine($"Account Number: {account.GetAccountNumber()}, Balance: {account.GetBalance()}");

    account.Withdraw(500);
    Console.WriteLine($"Withdraw 500, Balance: {account.GetBalance()}");

    account.Deposit(200);
    Console.WriteLine($"Deposit 200, Balance: {account.GetBalance()}");

    account.Withdraw(2000); 
}
catch (Exception ex)
{
    Console.WriteLine($"Exception: {ex.Message}");
}
        
    